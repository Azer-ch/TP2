#include<iostream>
#include "point_ex1.h"
using namespace std;
int main()
{
	point a ,b;
	cout<<"Saisir les coordonnées du point A\n ";
	cin >> a.x >> a.y ;
	cout<< "Saisir les coordonnées du point B\n";
	cin >> b.x >>b.y;
	cout<<"AB= "<<a.distance(b)<<endl;
	b=a.milieu(b);
	cout<<"Le point I milieu de [AB] est de coordonnées : "<<b.x<<" "<<b.y<<endl;

}
