#include<iostream>
#include<math.h>
#include"point_ex1.h"
using namespace std;
double point::distance(point &p)
{
return( sqrt( (x-p.x)*(x-p.x) + (y-p.y)*(y-p.y)  ) );
}
point point::milieu(point &p)
{
	
	p.x=double(x+p.x)/double(2);
	p.y=double(y+p.y)/double(2);
	return p;

}


