#ifndef point_ex1_h 
#define point_ex1_h
class point
{
	public:
		double x , y ;
	public:
	    
		double distance(point &p);
		point milieu(point &p);
};
#endif

