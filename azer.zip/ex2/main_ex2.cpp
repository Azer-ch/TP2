#include<iostream>
#include "point_ex2.h"
using namespace std;
int main()
{
	point a ,b;
	double u,v ;
	cout<<"Saisir les coordonnées du point A\n ";
	cin >> u >> v ;
	a.setx(u);
	a.sety(v);
	cout<< "Saisir les coordonnées du point B\n";
	cin >> u >>v;
	b.setx(u);
	b.sety(v);
	cout<<"AB= "<<a.distance(b)<<endl;
	b=a.milieu(b);
	cout<<"Le point I milieu de [AB] est de coordonnées : "<<b.getx()<<" "<<b.gety()<<endl;

}
