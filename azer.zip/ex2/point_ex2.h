#ifndef point_ex2_h 
#define point_ex2_h
class point
{
	private:
		double x , y ;
	public:
	    
		double distance(point &p);
		point milieu(point &p);
		double getx() const;
		double gety() const ;
		void setx(double a);
		void sety(double b);
};
#endif

